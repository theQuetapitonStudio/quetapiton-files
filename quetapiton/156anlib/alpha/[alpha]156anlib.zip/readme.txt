Warning! 
This library was specifically created for C++, 
but a C port will likely be available soon.