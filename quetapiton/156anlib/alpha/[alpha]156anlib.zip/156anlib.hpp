/* 

Simple ASCII animations lib

Made by Quetapiton Studio

*/

#include <iostream>
#include <string>
#include <windows.h>

using namespace std;

inline void createspanim(string charac) {
    for (int x = 0; x < 20; x++) {
        system("cls");
        for (int i = 0; i < x; i++) {
           cout << " ";
        }
        cout << charac;
        Sleep(100);
    }
}


inline void ssanim() {
    while (true) {
        system("cls");

        cout << "           .----.           .----.\n";
        cout << "          -|    |-          |    |\n";
        cout << "           -----            ----- \n";

        Sleep(300);

        system("cls");


        // frame 2
        cout << "\n";
        cout << "           .----.           .----.\n";
        cout << "          -|    |-          |    | \n";
        cout << "           -----            ----- \n";

        Sleep(300);
    }
}