#include "156anlib.hpp"
#include "rcs.hpp"

int main() {
    removeScroll();
    hideCursor();
    ssanim();
    system("pause >nul");
    return 0;
}